from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home_view(request):
    # return HttpResponse('home page')
    ls = ['Python' , 'CSS' , 'HTML' ,'JS', 'java','DB']
    context = {'courses':ls}
    return render(request , 'home.html',context)

def about_view(request):
    # return HttpResponse('about page')
    info = {
        'name':'Apeksha',
        'Age' : 23,
        'location':'Thane',
        'salary':20000
    }
    context = {'info' :info}
    return render(request , 'about.html',context)

def contact_view(request):
    # return HttpResponse('contact page..')  

    
    return render(request , 'contact.html')      
