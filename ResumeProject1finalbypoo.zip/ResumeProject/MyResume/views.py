from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def aboutme_view(request):
    
    return render(request, 'aboutme.html')

def skills_view(request):

    skills = {
        'Python':60,
        'JavaScript':70,
        'SQl':50,
        'HTML':90,
        'Css':75,
        'Django':20
    }

    context = {'skills':skills}

    return render(request , 'skills.html' , context)


def qualification_view(request):

    study = {
        'Ssc':{'Sr':1 , 'Study':'Ssc' , 'Boards':'Maharashtra' , 'Marks':90},
        'Hsc':{'Sr':2 , 'Study':'Hsc' , 'Boards':'Maharashtra' , 'Marks':80},
        'Btech':{'Sr':3 , 'Study':'Btech' , 'Boards':'Bhopal' , 'Marks':7.2}
    }

    context = {'study':study}

    return render(request , 'qualification.html' , context)

def experience_view(request):

    exp = {
        'Frontend-developer':'6 month',
        'Backend-developer':'7 month',
        'Python developer':'1 year'
    }

    context = {'exp':exp}

    return render(request , 'experience.html' , context)

def project_view(request):

    project = {'ResumeProject' :'Its a portfolio project made with the help of django', 
               'Hospital Management System':'Its a CLI based project made with the help of SQL and Python' , 
               'Registration Form':'Its a mini project made with the help of html css bootstrap'
               }
    context = {'project':project}

    return render(request , 'project.html' , context)

def contact_view(request):

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        p = request.POST.get('purpose')

        print(name)
        print(email)
        print(p)

        context = {'name':name}
        return render(request , 'thanks.html' , context)

    return render(request , 'contact.html')

